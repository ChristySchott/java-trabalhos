/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.text.MaskFormatter;
import modelDominio.Administrativo;
import modelDominio.Estudante;
import modelDominio.Professor;

/**
 *
 * @author aluno
 */
public class FormCadastroUsuario extends javax.swing.JDialog {

    SimpleDateFormat formatoData;
    MaskFormatter mfdata, mfdataInicio;
    
    

    public FormCadastroUsuario() {

        formatoData = new SimpleDateFormat("dd/MM/yyyy");

        try {
            mfdata = new MaskFormatter("##/##/####");
            mfdataInicio = new MaskFormatter("##/##/####");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        initComponents();

        mfdata.install(jtxtNascimento);
        mfdataInicio.install(jtxtDataInicio);

        jtxtNome.requestFocus();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jtxtNome = new javax.swing.JTextField();
        jtxtEmail = new javax.swing.JTextField();
        jtxtNascimento = new javax.swing.JFormattedTextField(formatoData);
        jpEstudante = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jtxtMatricula = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jtxtCurso = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jtxtIngresso = new javax.swing.JTextField();
        jbLimparEstudante = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jtxtArea = new javax.swing.JTextField();
        jtxtSetor = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jtxtDataInicio = new javax.swing.JFormattedTextField(formatoData);
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jcbTipo = new javax.swing.JComboBox();
        jtxtSenha = new javax.swing.JTextField();
        jbLimpar = new javax.swing.JButton();
        jbSalvar = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();

        jLabel13.setText("jLabel13");

        jLabel14.setText("jLabel14");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Nome:");

        jLabel2.setText("E-mail:");

        jLabel3.setText("Senha:");

        jLabel4.setText("Data de Nascimento:");

        jtxtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtNomeActionPerformed(evt);
            }
        });

        jpEstudante.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Estudante", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jLabel6.setText("Matricula:");

        jLabel7.setText("Curso:");

        jLabel8.setText("Ano de ingresso:");

        jbLimparEstudante.setText("Limpar Estudante");
        jbLimparEstudante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbLimparEstudanteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jpEstudanteLayout = new javax.swing.GroupLayout(jpEstudante);
        jpEstudante.setLayout(jpEstudanteLayout);
        jpEstudanteLayout.setHorizontalGroup(
            jpEstudanteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpEstudanteLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jbLimparEstudante)
                .addGap(77, 77, 77))
            .addGroup(jpEstudanteLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addGroup(jpEstudanteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtxtIngresso, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jtxtMatricula, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jtxtCurso, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        jpEstudanteLayout.setVerticalGroup(
            jpEstudanteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpEstudanteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxtMatricula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxtCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jtxtIngresso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jbLimparEstudante, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Servidor", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Administrativo", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Professor", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jLabel11.setText("Área:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jtxtArea, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxtArea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jLabel10.setText("Setor:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtxtSetor, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxtSetor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel9.setText("Data de início:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jtxtDataInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(62, 62, 62))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxtDataInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel5.setText("Tipo:");

        jcbTipo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Selecione\t", "Estudante\t", "Administrativo", "Professor" }));
        jcbTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbTipoActionPerformed(evt);
            }
        });

        jbLimpar.setText("Limpar tudo");
        jbLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbLimparActionPerformed(evt);
            }
        });

        jbSalvar.setText("Salvar");
        jbSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbSalvarActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));

        jLabel12.setFont(new java.awt.Font("Impact", 1, 30)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("CADASTRO DE USUÁRIO");
        jLabel12.setToolTipText("");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addGap(173, 173, 173))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jpEstudante, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(42, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jbLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jbSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42))))
            .addGroup(layout.createSequentialGroup()
                .addGap(226, 226, 226)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jcbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel5)
                        .addComponent(jLabel3)
                        .addComponent(jLabel2)
                        .addComponent(jLabel1)
                        .addComponent(jtxtNome)
                        .addComponent(jtxtEmail)
                        .addComponent(jtxtSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jtxtNascimento, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxtSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxtNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jcbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpEstudante, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jbSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jtxtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtNomeActionPerformed

    }//GEN-LAST:event_jtxtNomeActionPerformed

    private void jbSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbSalvarActionPerformed
        // TODO add your handling code here:
        Date dataNascimento;
        Date dataInicioServico;

        try {
            dataNascimento = (Date) jtxtNascimento.getValue();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Preencha o campo Data de Nascimento",
                    this.getTitle(), JOptionPane.ERROR_MESSAGE);
            jtxtNascimento.requestFocus();
            return;
        }

        try {
            dataInicioServico = (Date) jtxtDataInicio.getValue();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Preencha o campo Data de Início",
                    this.getTitle(), JOptionPane.ERROR_MESSAGE);
            jtxtDataInicio.requestFocus();
            return;
        }

        if (jtxtNome.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "O campo Nome é de preenchimento obrigatório!");
            jtxtNome.requestFocus();
        } else if (jtxtEmail.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "O campo E-mail é de preenchimento obrigatório!");
            jtxtEmail.requestFocus();
        } else if (jtxtSenha.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "O campo Senha é de preenchimento obrigatório!");
            jtxtSenha.requestFocus();
        } else if (jtxtNascimento.getValue().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "O campo Data de Nascimento é de preenchimento obrigatório!");
            jtxtNascimento.requestFocus();
        } else {

            if (jcbTipo.getSelectedIndex() == 1) {

                int anoIngresso = 0;
                try {
                    anoIngresso = Integer.parseInt(jtxtIngresso.getText());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(rootPane, "O campo Ano de Ingresso não está preenchido corretamente!");
                    jtxtIngresso.requestFocus();
                    return; // sai do codigo
                }

                if (jtxtMatricula.getText().equals("")) {
                    JOptionPane.showMessageDialog(rootPane, "O campo nome é de preenchimento obrigatorio");
                    jtxtCurso.requestFocus();
                } else if (jtxtCurso.getText().equals("")) {
                    JOptionPane.showMessageDialog(rootPane, "O campo curso é de preenchimento obrigatorio");
                    jtxtCurso.requestFocus();
                } else if (anoIngresso < 0) {
                    JOptionPane.showMessageDialog(rootPane, "O campo ano de ingresso não pode ser negativo");
                    jtxtIngresso.requestFocus();
                }

                Estudante user = new Estudante(jtxtMatricula.getText(), jtxtCurso.getText(), anoIngresso, jtxtNome.getText(), jtxtEmail.getText(), jtxtSenha.getText(), dataNascimento);
                // adicionando o objeto na lista do formulario principal
                FormPrincipal.lstUser.add(user);
               

            } else if (jcbTipo.getSelectedIndex() == 2) {
                if (jtxtDataInicio.getValue().equals("")) {
                    JOptionPane.showMessageDialog(rootPane, "O campo Data de Inicio é de preenchimento obrigatorio");
                    jtxtDataInicio.requestFocus();
                } else if (jtxtSetor.getText().equals("")) {
                    JOptionPane.showMessageDialog(rootPane, "O campo Setor é de preenchimento obrigatorio");
                    jtxtSetor.requestFocus();
                }

                Administrativo user = new Administrativo(jtxtSetor.getText(), dataInicioServico, jtxtNome.getText(), jtxtEmail.getText(), jtxtSenha.getText(), dataNascimento);
                // adicionando o objeto na lista do formulario principal
                FormPrincipal.lstUser.add(user);
                

            } else if (jcbTipo.getSelectedIndex() == 3) {
                if (jtxtDataInicio.getValue().equals("")) {
                    JOptionPane.showMessageDialog(rootPane, "O campo Data de Inicio é de preenchimento obrigatorio");
                    jtxtDataInicio.requestFocus();
                } else if (jtxtArea.getText().equals("")) {
                    JOptionPane.showMessageDialog(rootPane, "O campo Area é de preenchimento obrigatorio");
                    jtxtArea.requestFocus();
                }

                Professor user = new Professor(jtxtArea.getText(), dataInicioServico, jtxtNome.getText(), jtxtEmail.getText(), jtxtSenha.getText(), dataNascimento);
                // adicionando o objeto na lista do formulario principal
                FormPrincipal.lstUser.add(user);
                

            }
        }
             dispose();

    }//GEN-LAST:event_jbSalvarActionPerformed

    private void jbLimparEstudanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbLimparEstudanteActionPerformed
        // TODO add your handling code here:
        limpaEstudante();
    }//GEN-LAST:event_jbLimparEstudanteActionPerformed

    private void jbLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbLimparActionPerformed
        // TODO add your handling code here:
        limpaCampos();
    }//GEN-LAST:event_jbLimparActionPerformed

    private void jcbTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbTipoActionPerformed
        // TODO add your handling code here:
        switch (jcbTipo.getSelectedIndex()) {
            case 0:
                jtxtMatricula.setEnabled(false);
                jtxtCurso.setEnabled(false);
                jtxtIngresso.setEnabled(false);
                jtxtDataInicio.setEnabled(false);
                jtxtSetor.setEnabled(false);
                jtxtArea.setEnabled(false);
                break;
            case 1:
                jtxtMatricula.setEnabled(true);
                jtxtCurso.setEnabled(true);
                jtxtIngresso.setEnabled(true);
                jtxtArea.setEnabled(false);
                jtxtDataInicio.setEnabled(false);
                jtxtSetor.setEnabled(false);
                break;
            case 2:
                jtxtMatricula.setEnabled(false);
                jtxtCurso.setEnabled(false);
                jtxtIngresso.setEnabled(false);
                jtxtArea.setEnabled(false);
                jtxtSetor.setEnabled(true);
                jtxtDataInicio.setEnabled(true);
                break;
            case 3:
                jtxtMatricula.setEnabled(false);
                jtxtCurso.setEnabled(false);
                jtxtIngresso.setEnabled(false);
                jtxtSetor.setEnabled(false);
                jtxtArea.setEnabled(true);
                jtxtDataInicio.setEnabled(true);
                break;
        }

    }//GEN-LAST:event_jcbTipoActionPerformed

    public void limpaEstudante() {
        jtxtMatricula.setText("");
        jtxtCurso.setText("");
        jtxtIngresso.setText("");
    }

    public void limpaCampos() {
        jtxtNome.setText("");
        jtxtEmail.setText("");
        jtxtSenha.setText("");
        jtxtMatricula.setText("");
        jtxtCurso.setText("");
        jtxtIngresso.setText("");
        jtxtArea.setText("");
        jtxtSetor.setText("");
        jtxtDataInicio.setText("");
        jtxtNascimento.setText("");
        jcbTipo.setSelectedIndex(0);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormCadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormCadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormCadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormCadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormCadastroUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JButton jbLimpar;
    private javax.swing.JButton jbLimparEstudante;
    private javax.swing.JButton jbSalvar;
    private javax.swing.JComboBox jcbTipo;
    private javax.swing.JPanel jpEstudante;
    private javax.swing.JTextField jtxtArea;
    private javax.swing.JTextField jtxtCurso;
    private javax.swing.JFormattedTextField jtxtDataInicio;
    private javax.swing.JTextField jtxtEmail;
    private javax.swing.JTextField jtxtIngresso;
    private javax.swing.JTextField jtxtMatricula;
    private javax.swing.JFormattedTextField jtxtNascimento;
    private javax.swing.JTextField jtxtNome;
    private javax.swing.JTextField jtxtSenha;
    private javax.swing.JTextField jtxtSetor;
    // End of variables declaration//GEN-END:variables
}

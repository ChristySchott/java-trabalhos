/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelDominio;

import java.util.Date;

/**
 *
 * @author aluno
 */
public abstract class Servidor extends Usuario {
    
    private Date dataInicioServico;

    public Servidor(Date dataInicioServico, String nome, String email, String senha, Date dataNascimento) {
        super(nome, email, senha, dataNascimento);
        this.dataInicioServico = dataInicioServico;
    }

    public Date getDataInicioServico() {
        return dataInicioServico;
    }

    public void setDataInicioServico(Date dataInicioServico) {
        this.dataInicioServico = dataInicioServico;
    }
    
    
    
}

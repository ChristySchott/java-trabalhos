/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelDominio;

import java.util.Date;

/**
 *
 * @author aluno
 */
public class Professor extends Servidor {
    
    private String area;

    public Professor(String area, Date dataInicioServico, String nome, String email, String senha, Date dataNascimento) {
        super(dataInicioServico, nome, email, senha, dataNascimento);
        this.area = area;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
   
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelDominio;

import java.util.Date;

/**
 *
 * @author aluno
 */
public class Estudante extends Usuario{
    
    private String matricula;
    private String curso;
    private int anoIngresso;

    public Estudante(String matricula, String curso, int anoIngresso, String nome, String email, String senha, Date dataNascimento) {
        super(nome, email, senha, dataNascimento);
        this.matricula = matricula;
        this.curso = curso;
        this.anoIngresso = anoIngresso;
    }

    public int getAnoIngresso() {
        return anoIngresso;
    }

    public void setAnoIngresso(int anoIngresso) {
        this.anoIngresso = anoIngresso;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return super.toString()+"\nEstudante{" + "matricula=" + matricula + ", curso=" + curso + ", anoIngresso=" + anoIngresso + '}';
    }
    
    
    
}

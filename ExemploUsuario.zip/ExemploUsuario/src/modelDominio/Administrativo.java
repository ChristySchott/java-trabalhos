
package modelDominio;

import java.util.Date;


public class Administrativo extends Servidor {
    
    private String setor;

    public Administrativo(String setor, Date dataInicioServico, String nome, String email, String senha, Date dataNascimento) {
        super(dataInicioServico, nome, email, senha, dataNascimento);
        this.setor = setor;
    }

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }
       
    
}

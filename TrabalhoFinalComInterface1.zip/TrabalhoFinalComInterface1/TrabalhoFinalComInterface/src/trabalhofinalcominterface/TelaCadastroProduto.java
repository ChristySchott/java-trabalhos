package trabalhofinalcominterface;

import java.util.LinkedList;
import javax.swing.JOptionPane;

public class TelaCadastroProduto extends javax.swing.JFrame {

    LinkedList<Produto> listaProdutos;

    public TelaCadastroProduto(LinkedList<Produto> listaProdutos) {
        initComponents();
        this.listaProdutos = listaProdutos;

        jCBTipoDefeito.setEnabled(false);
        jTPDescricao.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLCodigo = new javax.swing.JLabel();
        jLNome = new javax.swing.JLabel();
        jLCategoria = new javax.swing.JLabel();
        jPDefeituoso = new javax.swing.JPanel();
        jLDefeituoso = new javax.swing.JLabel();
        jLTipoDefeito = new javax.swing.JLabel();
        jLDescricao = new javax.swing.JLabel();
        jCBDefeituoso = new javax.swing.JComboBox<>();
        jCBTipoDefeito = new javax.swing.JComboBox<>();
        jSPDescricao = new javax.swing.JScrollPane();
        jTPDescricao = new javax.swing.JTextPane();
        jTFCodigo = new javax.swing.JTextField();
        jTFNome = new javax.swing.JTextField();
        jCBCategoria = new javax.swing.JComboBox<>();
        jBSalvar = new javax.swing.JButton();
        jBCancelar = new javax.swing.JButton();
        jBVoltar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jTFQuantidade = new javax.swing.JTextField();
        jLDataValidade = new javax.swing.JLabel();
        jTFValidade = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 51, 51));

        jLCodigo.setText("Código:");

        jLNome.setText("Nome:");

        jLCategoria.setText("Categoria:");

        jPDefeituoso.setBorder(javax.swing.BorderFactory.createTitledBorder("Defeituoso"));

        jLDefeituoso.setText("Defeituoso:");

        jLTipoDefeito.setText("Tipo:");

        jLDescricao.setText("Descrição:");

        jCBDefeituoso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Não", "Sim", " " }));
        jCBDefeituoso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCBDefeituosoActionPerformed(evt);
            }
        });

        jCBTipoDefeito.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Item 1", "Item 2", "Item 3", "Item 4" }));

        jSPDescricao.setViewportView(jTPDescricao);

        javax.swing.GroupLayout jPDefeituosoLayout = new javax.swing.GroupLayout(jPDefeituoso);
        jPDefeituoso.setLayout(jPDefeituosoLayout);
        jPDefeituosoLayout.setHorizontalGroup(
            jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPDefeituosoLayout.createSequentialGroup()
                .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPDefeituosoLayout.createSequentialGroup()
                        .addGap(0, 51, Short.MAX_VALUE)
                        .addComponent(jLDescricao)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jSPDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPDefeituosoLayout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLTipoDefeito)
                            .addComponent(jLDefeituoso))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCBDefeituoso, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jCBTipoDefeito, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(43, 43, 43))
        );
        jPDefeituosoLayout.setVerticalGroup(
            jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPDefeituosoLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLDefeituoso)
                    .addComponent(jCBDefeituoso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLTipoDefeito)
                    .addComponent(jCBTipoDefeito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLDescricao)
                    .addComponent(jSPDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jCBCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Alimento", "Bebida\t", "Cosmético", "Higiene", "Utensílio", "Outro", " ", " " }));

        jBSalvar.setText("Salvar");
        jBSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBSalvarActionPerformed(evt);
            }
        });

        jBCancelar.setText("Apagar");
        jBCancelar.setToolTipText("");
        jBCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCancelarActionPerformed(evt);
            }
        });

        jBVoltar.setText("Voltar");
        jBVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBVoltarActionPerformed(evt);
            }
        });

        jLabel1.setText("Quantidade:");

        jLDataValidade.setText("Data de validade:");

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Impact", 0, 40)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("CADASTRAR PRODUTO");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(112, 112, 112)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel2)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(135, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLCategoria)
                            .addComponent(jLDataValidade)
                            .addComponent(jLCodigo)
                            .addComponent(jLNome))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTFQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jCBCategoria, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jTFCodigo)
                                .addComponent(jTFNome, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jTFValidade, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(212, 212, 212))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jBSalvar)
                        .addGap(41, 41, 41)
                        .addComponent(jBCancelar)
                        .addGap(37, 37, 37)
                        .addComponent(jBVoltar)
                        .addGap(173, 173, 173))))
            .addGroup(layout.createSequentialGroup()
                .addGap(112, 112, 112)
                .addComponent(jPDefeituoso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLCodigo))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLNome))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCBCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLCategoria))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFValidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLDataValidade))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(jPDefeituoso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBVoltar)
                    .addComponent(jBCancelar)
                    .addComponent(jBSalvar))
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCancelarActionPerformed

        limpaCampos();
    }//GEN-LAST:event_jBCancelarActionPerformed

    private void jCBDefeituosoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCBDefeituosoActionPerformed

        if (jCBDefeituoso.getSelectedIndex() == 0) {
            jCBTipoDefeito.setEnabled(false);
            jTPDescricao.setEnabled(false);
        } else if (jCBDefeituoso.getSelectedIndex() == 1) {
            jCBTipoDefeito.setEnabled(true);
            jTPDescricao.setEnabled(true);
        }


    }//GEN-LAST:event_jCBDefeituosoActionPerformed

    private void jBSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBSalvarActionPerformed

        if (!jTFCodigo.getText().equals("")) {
            if (!jTFNome.getText().equals("")) {
                if (jCBCategoria.getSelectedIndex() != 0) {
                    if (!jTFQuantidade.getText().equals("")) {
                        if (!jTFValidade.getText().equals("")) {

                            String codigo = jTFCodigo.getText();
                            String nome = jTFNome.getText();
                            int categoria = jCBCategoria.getSelectedIndex();
                            String quantidade = jTFQuantidade.getText();
                            String dataValidade = jTFValidade.getText();

                            if (jCBDefeituoso.getSelectedIndex() == 0) {
                                Produto meuProduto;
                                meuProduto = new Produto(codigo, nome, categoria, quantidade, dataValidade);
                                this.listaProdutos.add(meuProduto);

                                JOptionPane.showMessageDialog(rootPane, "Dados salvos com êxito!");
                                limpaCampos();

                            } else if (jCBDefeituoso.getSelectedIndex() == 1) {
                                if (jCBTipoDefeito.getSelectedIndex() != 0) {
                                    if (!jTPDescricao.getText().equals("")) {

                                        int tipo = jCBTipoDefeito.getSelectedIndex();
                                        String descricao = jTPDescricao.getText();

                                        ProdutoDefeituoso meuProdutoDefeituoso = new ProdutoDefeituoso(tipo, descricao, codigo, nome, categoria,quantidade,dataValidade);
                                        this.listaProdutos.add(meuProdutoDefeituoso);

                                        JOptionPane.showMessageDialog(rootPane, "Dados salvos com sucesso!");
                                        limpaCampos();

                                    } else {
                                        JOptionPane.showMessageDialog(rootPane, "Informe uma descrição para o defeito!");
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(rootPane, "Informe o tipo de defeito!");
                                }
                            }
                        } else {
                            JOptionPane.showConfirmDialog(rootPane, "Informe a validade!");
                        }

                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Informe a quantidade!");
                    }

                } else {
                    JOptionPane.showMessageDialog(rootPane, "Selecione a categoria");
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Informe o nome!");
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Informe o código");
        }
    
    }//GEN-LAST:event_jBSalvarActionPerformed

    private void jBVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBVoltarActionPerformed
        dispose();
    }//GEN-LAST:event_jBVoltarActionPerformed

    public void limpaCampos() {
        jTFCodigo.setText("");
        jTFNome.setText("");
        jCBCategoria.setSelectedIndex(0);
        jTFQuantidade.setText("");
        jTFValidade.setText("");
        jCBDefeituoso.setSelectedIndex(0);
        jCBTipoDefeito.setSelectedIndex(0);
        jTPDescricao.setText("");

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBCancelar;
    private javax.swing.JButton jBSalvar;
    private javax.swing.JButton jBVoltar;
    private javax.swing.JComboBox<String> jCBCategoria;
    private javax.swing.JComboBox<String> jCBDefeituoso;
    private javax.swing.JComboBox<String> jCBTipoDefeito;
    private javax.swing.JLabel jLCategoria;
    private javax.swing.JLabel jLCodigo;
    private javax.swing.JLabel jLDataValidade;
    private javax.swing.JLabel jLDefeituoso;
    private javax.swing.JLabel jLDescricao;
    private javax.swing.JLabel jLNome;
    private javax.swing.JLabel jLTipoDefeito;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPDefeituoso;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jSPDescricao;
    private javax.swing.JTextField jTFCodigo;
    private javax.swing.JTextField jTFNome;
    private javax.swing.JTextField jTFQuantidade;
    private javax.swing.JTextField jTFValidade;
    private javax.swing.JTextPane jTPDescricao;
    // End of variables declaration//GEN-END:variables
}

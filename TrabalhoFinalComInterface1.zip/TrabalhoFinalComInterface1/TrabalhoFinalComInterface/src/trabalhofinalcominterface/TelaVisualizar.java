package trabalhofinalcominterface;

import java.util.LinkedList;
import javax.swing.table.DefaultTableModel;

public class TelaVisualizar extends javax.swing.JFrame {

    LinkedList<Produto> listaProdutos;
    LinkedList<Estabelecimento> listaEstabelecimentos;

    public TelaVisualizar(LinkedList<Produto> listaProdutos,LinkedList<Estabelecimento> listaEstabelecimentos) {
        initComponents();
        this.listaProdutos = listaProdutos;
        this.listaEstabelecimentos = listaEstabelecimentos;

        // aqui carrego a tabela
        DefaultTableModel modelo = (DefaultTableModel) jTProdutos.getModel();
        modelo.setNumRows(0);

        for (int x = 0; x < this.listaProdutos.size(); x++) {
            Produto meuProduto = this.listaProdutos.get(x);

            modelo.addRow(new Object[]{});
            modelo.setValueAt(meuProduto.getCodigo(), x, 0);
            modelo.setValueAt(meuProduto.getNome(), x, 1);
            modelo.setValueAt(meuProduto.getCategoria(), x, 2);
            modelo.setValueAt(meuProduto.getQuantidade(), x, 3);
            modelo.setValueAt(meuProduto.getDataValidade(), x, 4);

            if (meuProduto instanceof ProdutoDefeituoso) {
                modelo.setValueAt("Sim", x, 5);
                ProdutoDefeituoso meuProdutoDefeituoso = (ProdutoDefeituoso) meuProduto;
                modelo.setValueAt(meuProdutoDefeituoso.getTipo(), x, 6);
            } else {
                modelo.setValueAt("Não", x, 5);
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTProdutos = new javax.swing.JTable();
        jBVoltarVisualizar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLTituloVisualizar = new javax.swing.JLabel();
        jBPparaE = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTProdutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Código", "Nome", "Categoria", "Quantidade", "Validade", "Defeito"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTProdutos);

        jBVoltarVisualizar.setText("Menu");
        jBVoltarVisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBVoltarVisualizarActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));

        jLTituloVisualizar.setFont(new java.awt.Font("Impact", 0, 40)); // NOI18N
        jLTituloVisualizar.setForeground(new java.awt.Color(255, 255, 255));
        jLTituloVisualizar.setText("VISUALIZAR PRODUTOS");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(242, 242, 242)
                .addComponent(jLTituloVisualizar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLTituloVisualizar)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jBPparaE.setText("Estabelecimentos");
        jBPparaE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBPparaEActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 773, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 39, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jBPparaE)
                .addGap(41, 41, 41)
                .addComponent(jBVoltarVisualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(279, 279, 279))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBVoltarVisualizar)
                    .addComponent(jBPparaE))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBVoltarVisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBVoltarVisualizarActionPerformed
        dispose();
    }//GEN-LAST:event_jBVoltarVisualizarActionPerformed

    private void jBPparaEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBPparaEActionPerformed

        TelaVisualizarEstabelecimentos telaVisualizarEstabelecimentos = new TelaVisualizarEstabelecimentos(this.listaEstabelecimentos,this.listaProdutos);
        telaVisualizarEstabelecimentos.setVisible(true);
    }//GEN-LAST:event_jBPparaEActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBPparaE;
    private javax.swing.JButton jBVoltarVisualizar;
    private javax.swing.JLabel jLTituloVisualizar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTProdutos;
    // End of variables declaration//GEN-END:variables
}

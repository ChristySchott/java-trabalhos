package trabalhofinalcominterface;

public class Produto {

    private String codigo;
    private String nome;
    private int categoria;
    private String quantidade;
    private String dataAtual;
    private String dataValidade;
    private int situacao; // não será usado como construtor, apenas para informar o vencimento ou não do produto
    
    Estabelecimento estabelecimento;
    

    public Produto(String codigo, String nome, int categoria, String quantidade, String dataAtual, String dataValidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.categoria = categoria;
        this.quantidade = quantidade;
        this.dataAtual = dataAtual;
        this.dataValidade = dataValidade;
    }

    public Produto(String codigo, String nome, int categoria, String quantidade, String dataValidade, Estabelecimento estabelecimento) {
        this.codigo = codigo;
        this.nome = nome;
        this.categoria = categoria;
        this.quantidade = quantidade;
        this.dataValidade = dataValidade;
        this.estabelecimento = estabelecimento;
    }
    

    public Produto(String codigo, String nome, int categoria, String quantidade, String dataValidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.categoria = categoria;
        this.quantidade = quantidade;
        this.dataValidade = dataValidade;
    }
    

    public String getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(String dataValidade) {
        this.dataValidade = dataValidade;
    }

    public String getDataAtual() {
        return dataAtual;
    }

    public void setDataAtual(String dataAtual) {
        this.dataAtual = dataAtual;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public int getSituacao() {
        return situacao;
    }

    public void setSituacao(int situacao) {
        this.situacao = situacao;
    }
    
     public String getSituacaoLiteral() {
        String retorno = "";
        
        if (this.situacao == 1) {
            retorno = "Produto vencido.";
        } else {
            retorno = "Produto não está vencido.";
        }
        return retorno;
    }

    public Estabelecimento getEstabelecimento() {
        return estabelecimento;
    }

    public void setEstabelecimento(Estabelecimento estabelecimento) {
        this.estabelecimento = estabelecimento;
    }

}

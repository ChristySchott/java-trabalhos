
package trabalhofinalcominterface;


public class TrabalhoFinalComInterface {

    
    public static void main(String[] args) {
        
    }
    
}

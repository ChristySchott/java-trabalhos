
package trabalhofinalcominterface;


public class ProdutoDefeituoso extends Produto {
    int tipo;
    String descricao;

    public ProdutoDefeituoso(int tipo, String descricao, String codigo, String nome, int categoria, String quantidade, String dataAtual, String dataValidade) {
        super(codigo, nome, categoria, quantidade, dataAtual, dataValidade);
        this.tipo = tipo;
        this.descricao = descricao;
    }

    public ProdutoDefeituoso(int tipo, String descricao, String codigo, String nome, int categoria, String quantidade, String dataValidade) {
        super(codigo, nome, categoria, quantidade, dataValidade);
        this.tipo = tipo;
        this.descricao = descricao;
    }
    
    
    

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
        public String getTipoLiteral(){
    String retorno = " ";
    if(this.tipo == 1){
        retorno="Embalagem danifacada";
    } else if(this.tipo == 2){
        retorno="Produto quebrado";
    } else if(this.tipo == 3){
        retorno="Produto incompleto";
    } else if(this.tipo == 4){
        retorno="Produto fora da embalagem";
    } 
    return retorno;
    
}
    
    
}

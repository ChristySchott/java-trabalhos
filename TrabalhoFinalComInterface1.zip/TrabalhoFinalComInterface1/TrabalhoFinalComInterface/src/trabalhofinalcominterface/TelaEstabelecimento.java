package trabalhofinalcominterface;

import java.util.LinkedList;
import javax.swing.JOptionPane;

public class TelaEstabelecimento extends javax.swing.JFrame {

    LinkedList<Estabelecimento> listaEstabelecimentos;
    LinkedList<Produto> listaProdutos;

    public TelaEstabelecimento(LinkedList<Estabelecimento> listaEstabelecimentos, LinkedList<Produto> listaProdutos) {
        initComponents();
        this.listaEstabelecimentos = listaEstabelecimentos;
        this.listaProdutos=listaProdutos;
        
        jCBProduto.addItem("Selecionar o produto");
        for (int x = 0; x < this.listaProdutos.size(); x++) {
            Produto meuProduto = this.listaProdutos.get(x);
            jCBProduto.addItem("Produto: " + meuProduto.getNome());
    }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLCNPJ = new javax.swing.JLabel();
        jLNomeEstabelecimento = new javax.swing.JLabel();
        jLTipoEstabelecimento = new javax.swing.JLabel();
        jPEndereco = new javax.swing.JPanel();
        jLRua = new javax.swing.JLabel();
        jLBairro = new javax.swing.JLabel();
        jLNumero = new javax.swing.JLabel();
        jLComplemento = new javax.swing.JLabel();
        jLEstado = new javax.swing.JLabel();
        jLCidade = new javax.swing.JLabel();
        jLCep = new javax.swing.JLabel();
        jLTelefone = new javax.swing.JLabel();
        jTFRua = new javax.swing.JTextField();
        jTFBairro = new javax.swing.JTextField();
        jTFNumero = new javax.swing.JTextField();
        jTFComplemento = new javax.swing.JTextField();
        jCBEstado = new javax.swing.JComboBox<>();
        jTFCidade = new javax.swing.JTextField();
        jTFCep = new javax.swing.JTextField();
        jTFTelefone = new javax.swing.JTextField();
        jTFCnpj = new javax.swing.JTextField();
        jTFNomeEstabelecimento = new javax.swing.JTextField();
        jCBTipoEstabelecimento = new javax.swing.JComboBox<>();
        jBSalvarEstabelecimento = new javax.swing.JButton();
        jBCancelar = new javax.swing.JButton();
        jBVoltarEstabelecimento = new javax.swing.JButton();
        jCBProduto = new javax.swing.JComboBox<>();
        jLEProduto = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLCNPJ.setText("CNPJ:");

        jLNomeEstabelecimento.setText("Nome:");

        jLTipoEstabelecimento.setText("Tipo:");

        jPEndereco.setBorder(javax.swing.BorderFactory.createTitledBorder("Endereço"));

        jLRua.setText("Rua:");

        jLBairro.setText("Bairro:");

        jLNumero.setText("Nº:");

        jLComplemento.setText("Comp.:");

        jLEstado.setText("Estado:");

        jLCidade.setText("Cidade:");

        jLCep.setText("CEP:");

        jLTelefone.setText("Telefone:");

        jCBEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Acre", "Alagoas", "Amapá", "Amazonas", "Bahia", "Ceará", "Distrito Federal", "Espírito Santo", "Goiás", "Maranhão", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará", "Paraíba", "Paraná", "Pernambuco", "Piauí", "Rio de Janeiro", "Rio Grande do Norte", "Rio Grande do Sul", "Rondônia", "Roraima", "Santa Catarina", "São Paulo", "Sergipe", "Tocantins" }));

        javax.swing.GroupLayout jPEnderecoLayout = new javax.swing.GroupLayout(jPEndereco);
        jPEndereco.setLayout(jPEnderecoLayout);
        jPEnderecoLayout.setHorizontalGroup(
            jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPEnderecoLayout.createSequentialGroup()
                .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPEnderecoLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLCep)
                            .addComponent(jLCidade))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTFCidade)
                            .addComponent(jTFCep)))
                    .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPEnderecoLayout.createSequentialGroup()
                            .addGap(24, 24, 24)
                            .addComponent(jLEstado)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jCBEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPEnderecoLayout.createSequentialGroup()
                            .addGap(26, 26, 26)
                            .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLNumero)
                                .addComponent(jLBairro)
                                .addComponent(jLRua)
                                .addComponent(jLComplemento))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTFRua)
                                .addComponent(jTFBairro)
                                .addComponent(jTFComplemento)
                                .addGroup(jPEnderecoLayout.createSequentialGroup()
                                    .addComponent(jTFNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jLTelefone)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jTFTelefone, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))))))
                .addGap(60, 60, 60))
        );
        jPEnderecoLayout.setVerticalGroup(
            jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPEnderecoLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLRua)
                    .addComponent(jTFRua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLBairro)
                    .addComponent(jTFBairro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLNumero)
                    .addComponent(jTFNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLTelefone)
                    .addComponent(jTFTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFComplemento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLComplemento))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCBEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLEstado))
                .addGap(18, 18, 18)
                .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLCidade))
                .addGap(18, 18, 18)
                .addGroup(jPEnderecoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLCep)
                    .addComponent(jTFCep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jCBTipoEstabelecimento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Atacado", "Bazar", "Mercado", "Outro" }));

        jBSalvarEstabelecimento.setText("Salvar");
        jBSalvarEstabelecimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBSalvarEstabelecimentoActionPerformed(evt);
            }
        });

        jBCancelar.setText("Apagar");
        jBCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCancelarActionPerformed(evt);
            }
        });

        jBVoltarEstabelecimento.setText("Voltar");
        jBVoltarEstabelecimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBVoltarEstabelecimentoActionPerformed(evt);
            }
        });

        jLEProduto.setText("Produto:");

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));

        jLabel1.setFont(new java.awt.Font("Impact", 0, 40)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CADASTRAR ESTABELECIMENTO");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(63, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(50, 50, 50))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(110, 110, 110)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(48, 48, 48)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLTipoEstabelecimento, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLNomeEstabelecimento, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLCNPJ, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLEProduto, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jCBProduto, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jTFCnpj)
                                .addComponent(jTFNomeEstabelecimento)
                                .addComponent(jCBTipoEstabelecimento, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jPEndereco, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jBSalvarEstabelecimento, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(47, 47, 47)
                        .addComponent(jBCancelar)
                        .addGap(50, 50, 50)
                        .addComponent(jBVoltarEstabelecimento, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCBProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLEProduto))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLCNPJ)
                    .addComponent(jTFCnpj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLNomeEstabelecimento)
                    .addComponent(jTFNomeEstabelecimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLTipoEstabelecimento)
                    .addComponent(jCBTipoEstabelecimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBCancelar)
                    .addComponent(jBVoltarEstabelecimento)
                    .addComponent(jBSalvarEstabelecimento))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCancelarActionPerformed

        limpaCampos();
    }//GEN-LAST:event_jBCancelarActionPerformed

    private void jBSalvarEstabelecimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBSalvarEstabelecimentoActionPerformed
        if (jCBProduto.getSelectedIndex() != 0) {
            if (!jTFCnpj.getText().equals("")) {
                if (!jTFNomeEstabelecimento.getText().equals("")) {
                    if (jCBTipoEstabelecimento.getSelectedIndex() != 0) {

                        if (!jTFRua.getText().equals("")) {
                            if (!jTFNumero.getText().equals("")) {
                                if (!jTFBairro.getText().equals("")) {
                                    if (!jTFCidade.getText().equals("")) {
                                        if (jCBEstado.getSelectedIndex() != 0) {
                                            if (!jTFCep.getText().equals("")) {

                                                int indiceProduto = jCBProduto.getSelectedIndex() - 1;
                                                Produto meuProduto = this.listaProdutos.get(indiceProduto);
                                                String cnpj = jTFCnpj.getText();
                                                String nomeEstabelecimento = jTFNomeEstabelecimento.getText();
                                                int tipoDeEstabelecimento = jCBTipoEstabelecimento.getSelectedIndex();

                                                // endereço
                                                String rua = jTFRua.getText();
                                                String bairro = jTFBairro.getText();
                                                try {
                                                    String numero = jTFNumero.getText();
                                                    String telefone = jTFTelefone.getText();

                                                } catch (Exception erro) {
                                                    JOptionPane.showMessageDialog(rootPane, "Digite somente números");
                                                }
                                                String numero = jTFNumero.getText();
                                                String complemento = jTFComplemento.getText();
                                                String cidade = jTFCidade.getText();
                                                int estado = jCBEstado.getSelectedIndex();
                                                String cep = jTFCep.getText();

                                                // String rua, String bairro, String numero, String complemento, int estado, String cidade, String cep, String telefone
                                                Endereco meuEndereco = new Endereco(rua, bairro, numero, estado, cidade, cep);
                                                /*meuEndereco.setComplemento(complemento);
                                                meuEndereco.setTelefone(telefone);*/
                                                Estabelecimento meuEstabelecimento = new Estabelecimento(nomeEstabelecimento, cnpj, tipoDeEstabelecimento, meuEndereco,meuProduto);
                                                this.listaEstabelecimentos.add(meuEstabelecimento);

                                                JOptionPane.showMessageDialog(rootPane, "Estabelecimento cadastrado com sucesso!");
                                                limpaCampos();

                                            } else {
                                                JOptionPane.showMessageDialog(rootPane, "Informe o CEP!");
                                            }
                                        } else {
                                            JOptionPane.showMessageDialog(rootPane, "Informe o estado!");
                                        }
                                    } else {
                                        JOptionPane.showMessageDialog(rootPane, "Informe a cidade!");
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(rootPane, "Informe o bairro!");
                                }
                            } else {
                                JOptionPane.showMessageDialog(rootPane, "Informe o número!");
                            }
                        } else {
                            JOptionPane.showMessageDialog(rootPane, "Informe a rua!");
                        }

                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Selecione o tipo de estabelecimento");
                    }
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Informe o nome!");
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Informe o CNPJ!");
            }
        }else {
            JOptionPane.showMessageDialog(rootPane, "Você precisa atribuir um produto ao estabelecimento. Caso não houver nenhum, faça o cadastro.");
        }
        
    }//GEN-LAST:event_jBSalvarEstabelecimentoActionPerformed

    private void jBVoltarEstabelecimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBVoltarEstabelecimentoActionPerformed
        dispose();
    }//GEN-LAST:event_jBVoltarEstabelecimentoActionPerformed

    public void limpaCampos() {
        jTFCnpj.setText("");
        jTFNomeEstabelecimento.setText("");
        jCBTipoEstabelecimento.setSelectedIndex(0);
        jTFRua.setText("");
        jTFBairro.setText("");
        jTFNumero.setText("");
        jTFTelefone.setText("");
        jTFComplemento.setText("");
        jCBEstado.setSelectedIndex(0);
        jTFCidade.setText("");
        jTFCep.setText("");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBCancelar;
    private javax.swing.JButton jBSalvarEstabelecimento;
    private javax.swing.JButton jBVoltarEstabelecimento;
    private javax.swing.JComboBox<String> jCBEstado;
    private javax.swing.JComboBox<String> jCBProduto;
    private javax.swing.JComboBox<String> jCBTipoEstabelecimento;
    private javax.swing.JLabel jLBairro;
    private javax.swing.JLabel jLCNPJ;
    private javax.swing.JLabel jLCep;
    private javax.swing.JLabel jLCidade;
    private javax.swing.JLabel jLComplemento;
    private javax.swing.JLabel jLEProduto;
    private javax.swing.JLabel jLEstado;
    private javax.swing.JLabel jLNomeEstabelecimento;
    private javax.swing.JLabel jLNumero;
    private javax.swing.JLabel jLRua;
    private javax.swing.JLabel jLTelefone;
    private javax.swing.JLabel jLTipoEstabelecimento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPEndereco;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTFBairro;
    private javax.swing.JTextField jTFCep;
    private javax.swing.JTextField jTFCidade;
    private javax.swing.JTextField jTFCnpj;
    private javax.swing.JTextField jTFComplemento;
    private javax.swing.JTextField jTFNomeEstabelecimento;
    private javax.swing.JTextField jTFNumero;
    private javax.swing.JTextField jTFRua;
    private javax.swing.JTextField jTFTelefone;
    // End of variables declaration//GEN-END:variables
}

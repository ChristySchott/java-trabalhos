package trabalhofinalcominterface;

public class Estabelecimento {

    private String nomeEstabelecimento;
    private String CNPJ;
    private int tipoDeEstabelecimento;

    Endereco endereco;
    Produto produto;
    

    public Estabelecimento(String nomeEstabelecimento, String CNPJ, int tipoDeEstabelecimento, Endereco endereco, Produto produto) {
        this.nomeEstabelecimento = nomeEstabelecimento;
        this.CNPJ = CNPJ;
        this.tipoDeEstabelecimento = tipoDeEstabelecimento;
        this.endereco = endereco;
        this.produto = produto;
    }

    public int getTipoDeEstabelecimento() {
        return tipoDeEstabelecimento;
    }

    public void setTipoDeEstabelecimento(int tipoDeEstabelecimento) {
        this.tipoDeEstabelecimento = tipoDeEstabelecimento;
    }

    public String getNomeEstabelecimento() {
        return nomeEstabelecimento;
    }

    public void setNomeEstabelecimento(String nomeEstabelecimento) {
        this.nomeEstabelecimento = nomeEstabelecimento;
    }

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }
    
    
}

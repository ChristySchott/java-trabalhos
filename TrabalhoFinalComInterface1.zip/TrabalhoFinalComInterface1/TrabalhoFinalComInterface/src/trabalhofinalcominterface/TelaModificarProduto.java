package trabalhofinalcominterface;

import java.util.LinkedList;
import javax.swing.JOptionPane;

public class TelaModificarProduto extends javax.swing.JFrame {

    LinkedList<Produto> listaProdutos;

    public TelaModificarProduto(LinkedList<Produto> listaProdutos) {
        initComponents();
        this.listaProdutos = listaProdutos;

        jCBProdutoInformar.addItem("Selecionar produto");
        for (int x = 0; x < this.listaProdutos.size(); x++) {
            Produto meuProduto = this.listaProdutos.get(x);
            jCBProdutoInformar.addItem(meuProduto.getCodigo() + " - " + meuProduto.getNome());
        }

        jCBTipoDefeito.setEnabled(false);
        jTPDescricao.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTFQuantidade = new javax.swing.JTextField();
        jLDataValidade = new javax.swing.JLabel();
        jTFValidade = new javax.swing.JTextField();
        jLCodigo = new javax.swing.JLabel();
        jTFCodigo = new javax.swing.JTextField();
        jLNome = new javax.swing.JLabel();
        jTFNome = new javax.swing.JTextField();
        jLCategoria = new javax.swing.JLabel();
        jCBCategoria = new javax.swing.JComboBox<>();
        jPDefeituoso = new javax.swing.JPanel();
        jLDefeituoso = new javax.swing.JLabel();
        jLTipoDefeito = new javax.swing.JLabel();
        jLDescricao = new javax.swing.JLabel();
        jCBDefeituoso = new javax.swing.JComboBox<>();
        jCBTipoDefeito = new javax.swing.JComboBox<>();
        jSPDescricao = new javax.swing.JScrollPane();
        jTPDescricao = new javax.swing.JTextPane();
        jBSalvar = new javax.swing.JButton();
        jBCancelar = new javax.swing.JButton();
        jBVoltar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jCBProdutoInformar = new javax.swing.JComboBox<>();
        jLProdutoInformar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLDataValidade.setText("Data de validade:");

        jLCodigo.setText("Código:");

        jLNome.setText("Nome:");

        jLCategoria.setText("Categoria:");

        jCBCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Alimento", "Bebida\t", "Cosmético", "Higiene", "Utensílio", "Outro", " ", " " }));

        jPDefeituoso.setBorder(javax.swing.BorderFactory.createTitledBorder("Defeituoso"));

        jLDefeituoso.setText("Defeituoso:");

        jLTipoDefeito.setText("Tipo:");

        jLDescricao.setText("Descrição:");

        jCBDefeituoso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Não", "Sim", " " }));
        jCBDefeituoso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCBDefeituosoActionPerformed(evt);
            }
        });

        jCBTipoDefeito.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Item 1", "Item 2", "Item 3", "Item 4" }));

        jSPDescricao.setViewportView(jTPDescricao);

        javax.swing.GroupLayout jPDefeituosoLayout = new javax.swing.GroupLayout(jPDefeituoso);
        jPDefeituoso.setLayout(jPDefeituosoLayout);
        jPDefeituosoLayout.setHorizontalGroup(
            jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPDefeituosoLayout.createSequentialGroup()
                .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPDefeituosoLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLDescricao)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSPDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPDefeituosoLayout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLDefeituoso)
                            .addComponent(jLTipoDefeito))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jCBDefeituoso, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jCBTipoDefeito, 0, 138, Short.MAX_VALUE))))
                .addContainerGap(55, Short.MAX_VALUE))
        );
        jPDefeituosoLayout.setVerticalGroup(
            jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPDefeituosoLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLDefeituoso)
                    .addComponent(jCBDefeituoso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLTipoDefeito)
                    .addComponent(jCBTipoDefeito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPDefeituosoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLDescricao)
                    .addComponent(jSPDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jBSalvar.setText("Salvar");
        jBSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBSalvarActionPerformed(evt);
            }
        });

        jBCancelar.setText("Apagar");
        jBCancelar.setToolTipText("");
        jBCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCancelarActionPerformed(evt);
            }
        });

        jBVoltar.setText("Voltar");
        jBVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBVoltarActionPerformed(evt);
            }
        });

        jLabel1.setText("Quantidade:");

        jCBProdutoInformar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCBProdutoInformarActionPerformed(evt);
            }
        });

        jLProdutoInformar.setText("Produto:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLCodigo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTFCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLNome)
                                    .addComponent(jLCategoria))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jCBCategoria, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTFNome, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLDataValidade))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTFQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTFValidade, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(261, 261, 261))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(170, 170, 170)
                        .addComponent(jPDefeituoso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(215, 215, 215)
                        .addComponent(jBSalvar)
                        .addGap(30, 30, 30)
                        .addComponent(jBCancelar)
                        .addGap(18, 18, 18)
                        .addComponent(jBVoltar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(161, 161, 161)
                        .addComponent(jLProdutoInformar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCBProdutoInformar, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(174, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(77, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLProdutoInformar)
                    .addComponent(jCBProdutoInformar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLCodigo)
                    .addComponent(jTFCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLNome)
                    .addComponent(jTFNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLCategoria)
                    .addComponent(jCBCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTFQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLDataValidade)
                    .addComponent(jTFValidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPDefeituoso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBSalvar)
                    .addComponent(jBCancelar)
                    .addComponent(jBVoltar))
                .addGap(74, 74, 74))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCBDefeituosoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCBDefeituosoActionPerformed

        if (jCBDefeituoso.getSelectedIndex() == 0) {
            jCBTipoDefeito.setEnabled(false);
            jTPDescricao.setEnabled(false);
        } else if (jCBDefeituoso.getSelectedIndex() == 1) {
            jCBTipoDefeito.setEnabled(true);
            jTPDescricao.setEnabled(true);
        }

    }//GEN-LAST:event_jCBDefeituosoActionPerformed

    private void jBSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBSalvarActionPerformed

        if (jCBProdutoInformar.getSelectedIndex() != 0) {
            if (!jTFCodigo.getText().equals("")) {
                if (!jTFNome.getText().equals("")) {
                    if (jCBCategoria.getSelectedIndex() != 0) {
                        if (!jTFQuantidade.getText().equals("")) {
                            if (!jTFValidade.getText().equals("")) {

                                String codigo = jTFCodigo.getText();
                                String nome = jTFNome.getText();
                                int categoria = jCBCategoria.getSelectedIndex();
                                String quantidade = jTFQuantidade.getText();
                                String dataValidade = jTFValidade.getText();
                                int indice = jCBProdutoInformar.getSelectedIndex() - 1;
                                Produto meuProduto = this.listaProdutos.get(indice);
                                meuProduto.setCodigo(codigo);
                                meuProduto.setNome(nome);
                                meuProduto.setCategoria(categoria);
                                meuProduto.setQuantidade(quantidade);
                                meuProduto.setDataValidade(dataValidade);

                                JOptionPane.showMessageDialog(rootPane, "Produto atualizado com sucesso!");
                                limpaCampos();

                            } else {
                                JOptionPane.showConfirmDialog(rootPane, "Informe a validade!");
                            }

                        } else {
                            JOptionPane.showMessageDialog(rootPane, "Informe a quantidade!");
                        }

                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Selecione a categoria");
                    }
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Informe o nome!");
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Informe o código");
            }
        } else {
            JOptionPane.showConfirmDialog(rootPane, "Selecione um produto!");
        }

    }//GEN-LAST:event_jBSalvarActionPerformed

    private void jBCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCancelarActionPerformed

        limpaCampos();
    }//GEN-LAST:event_jBCancelarActionPerformed

    private void jBVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBVoltarActionPerformed
        dispose();
    }//GEN-LAST:event_jBVoltarActionPerformed

    private void jCBProdutoInformarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCBProdutoInformarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCBProdutoInformarActionPerformed

    public void limpaCampos() {
        jTFCodigo.setText("");
        jTFNome.setText("");
        jCBCategoria.setSelectedIndex(0);
        jTFQuantidade.setText("");
        jTFValidade.setText("");
        jCBDefeituoso.setSelectedIndex(0);
        jCBTipoDefeito.setSelectedIndex(0);
        jTPDescricao.setText("");

    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBCancelar;
    private javax.swing.JButton jBSalvar;
    private javax.swing.JButton jBVoltar;
    private javax.swing.JComboBox<String> jCBCategoria;
    private javax.swing.JComboBox<String> jCBDefeituoso;
    private javax.swing.JComboBox<String> jCBProdutoInformar;
    private javax.swing.JComboBox<String> jCBTipoDefeito;
    private javax.swing.JLabel jLCategoria;
    private javax.swing.JLabel jLCodigo;
    private javax.swing.JLabel jLDataValidade;
    private javax.swing.JLabel jLDefeituoso;
    private javax.swing.JLabel jLDescricao;
    private javax.swing.JLabel jLNome;
    private javax.swing.JLabel jLProdutoInformar;
    private javax.swing.JLabel jLTipoDefeito;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPDefeituoso;
    private javax.swing.JScrollPane jSPDescricao;
    private javax.swing.JTextField jTFCodigo;
    private javax.swing.JTextField jTFNome;
    private javax.swing.JTextField jTFQuantidade;
    private javax.swing.JTextField jTFValidade;
    private javax.swing.JTextPane jTPDescricao;
    // End of variables declaration//GEN-END:variables
}

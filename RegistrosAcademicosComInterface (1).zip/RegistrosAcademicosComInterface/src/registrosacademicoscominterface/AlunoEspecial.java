package registrosacademicoscominterface;


public class AlunoEspecial extends Aluno {
    private int tipo; //1=visual, 2=auditiva, 3=mental, 4=fisica, 5=multiplas
    private String datalaudo;
    private String profissionalLaudo;

    public AlunoEspecial(int tipo, String datalaudo, String matricula, String nome, int curso, Endereco endereco) {
        super(matricula, nome, curso, endereco);
        this.tipo = tipo;
        this.datalaudo = datalaudo;
    }
    
    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public String getDatalaudo() {
        return datalaudo;
    }

    public void setDatalaudo(String datalaudo) {
        this.datalaudo = datalaudo;
    }

    public String getProfissionalLaudo() {
        return profissionalLaudo;
    }

    public void setProfissionalLaudo(String profissionalLaudo) {
        this.profissionalLaudo = profissionalLaudo;
    }  
    
    public String getTipoLiteral(){
    String retorno = " ";
    if(this.tipo == 1){
        retorno="Visual";
    } else if(this.tipo == 2){
        retorno="Auditiva";
    } else if(this.tipo == 3){
        retorno="Mental";
    } else if(this.tipo == 4){
        retorno="Fisica";
    } else if(this.tipo == 5){
        retorno="Multipla";
    }
    return retorno;
    
}
}

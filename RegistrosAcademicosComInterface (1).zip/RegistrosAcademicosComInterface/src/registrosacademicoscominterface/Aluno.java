/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registrosacademicoscominterface;

/**
 *
 * @author aluno
 */
public class Aluno {
    private String matricula;
    private String nome;
    private int curso;
    private float nota1;
    private float nota2;
    private float nota3;
    private float frequencia;
    private int situacao; // Não é construtor.
    private float media; //  Não é construtor.
    
    Endereco endereco;

    public Aluno(String matricula, String nome, int curso, Endereco endereco) {
        this.matricula = matricula;
        this.nome = nome;
        this.curso = curso;
        this.endereco = endereco;
    }

    public Aluno (String matricula, String nome, int curso, float nota1, float nota2, float nota3, float frequencia) {
        this.matricula = matricula;
        this.nome = nome;
        this.curso = curso;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
        this.frequencia = frequencia;
    } 
    
    public void CalcularMedia () {
        this.media = (this.nota1 + this.nota2 + this.nota3) /3;
    }
    
    public void VerificarSituacao () {
        if (this.media >= 6 && this.frequencia >= 75) {
            this.situacao = 1;
        } else {
            this.situacao = 0;
        }
    }

    public float getFrequencia() {
        return frequencia;
    }

    public void setFrequencia(float frequencia) {
        this.frequencia = frequencia;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCurso() {
        return curso;
    }

    public void setCurso(int curso) {
        this.curso = curso;
    }

    public float getNota1() {
        return nota1;
    }

    public void setNota1(float nota1) {
        this.nota1 = nota1;
    }

    public float getNota2() {
        return nota2;
    }

    public void setNota2(float nota2) {
        this.nota2 = nota2;
    }

    public float getNota3() {
        return nota3;
    }

    public void setNota3(float nota3) {
        this.nota3 = nota3;
    }

    public int getSituacao() {
        return situacao;
    }

    public void setSituacao(int situacao) {
        this.situacao = situacao;
    }

    public float getMedia() {
        return media;
    }

    public void setMedia(float media) {
        this.media = media;
    }
    
    public String getSituacaoLiteral() {
        String retorno = "";
        
        if (this.situacao == 1) {
            retorno = "aprovado!";
        } else {
            retorno = "reprovado!";
        }
        return retorno;
    }
    
     public String getCursoLiteral() {
        String retorno = "";
        
        if (this.curso == 1) {
            retorno = "Informática";
        } else {
            retorno = "Refrigeração";
        }
        return retorno;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }
     
}


package modelDominio;

/**
 *
 * @author aluno
 */
public class EmpregadoAssalariado extends Empregado {
    private double salarioMensal;

    public double getSalarioMensal() {
        return salarioMensal;
    }

    public void setSalarioMensal(double salarioMensal) {
        this.salarioMensal = salarioMensal;
    }

    public EmpregadoAssalariado(double salarioMensal, String nome, String sobrenome) {
        super(nome, sobrenome);
        this.salarioMensal = salarioMensal;
    }
    
    @Override
    public double calculaSalario() {
        return salarioMensal;
    }
    
}

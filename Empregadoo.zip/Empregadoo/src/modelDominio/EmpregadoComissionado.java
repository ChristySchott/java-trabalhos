/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelDominio;

/**
 *
 * @author aluno
 */
public class EmpregadoComissionado extends Empregado{
    private double vendasBrutas;
    private double comissao;
    
        public EmpregadoComissionado(double vendasBrutas, double comissao, String nome, String sobrenome) {
        super(nome, sobrenome);
        this.vendasBrutas = vendasBrutas;
        this.comissao = comissao;
    }

    public double getVendasBrutas() {
        return vendasBrutas;
    }

    public void setVendasBrutas(double vendasBrutas) {
        this.vendasBrutas = vendasBrutas;
    }

    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }


    @Override
    public double calculaSalario() {
        return vendasBrutas*comissao;
    }
    
}
